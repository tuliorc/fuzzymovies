Para a aplica��o funcionar, siga os seguintes passos 
	
	1) Importar o projeto na IDE Netbeans
	2) Clicar com o bot�o direto no Projeto e Executar
	3) Inserir o ID de um usu�rio da lista de teste(abaixo)
	4) Inserir o ID de um filme que voc� deseja saber o quanto o usu�rio vai gostar. Valores poss�veis: 1 a 20
	5) Observa��o. O calculo da nota estimada pode demorar, devido as pesquisas no banco.
	6) [Opcional] para gr�ficos e print das regras, clicar com o bot�o direto na classe FuzzyMovies e clicar em Executar 	   Arquivo

Lista simples de Usu�rios para Teste
	
1488844
822109
885013
30878
823519
893988
124105
1248029
1842128
2238063
1503895
2207774
2590061
2442
543865
1209119
804919
1086807
1711859
372233"



	