package com.ufabc.fuzzy.converter;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

import com.ufabc.fuzzy.data.ConnectionFactory;
import com.ufabc.fuzzy.data.DataInsert;

public class StartConversion {

	public static void main(String[] args) throws SQLException{
		Reader reader = new Reader();
		
		ArrayList<String> movies = new ArrayList<String>();
		Random randomNumber = new Random();
		
		ArrayList<String> ratings = new ArrayList<String>();
		ArrayList<String> rateFiles = new ArrayList<String>();
		
		ConnectionFactory connectionFactory = new ConnectionFactory();
		Connection con = null;
		DataInsert dataInsert = null;
		
		try{
			con = connectionFactory.getConnection("./data/netflix.db");
			dataInsert = new DataInsert(con);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		try {
			
			System.out.println("Inserting...");
			
			FolderReader folderReader = new FolderReader();
			File file = new File("./NetflixFiles/MovieRatings");
			rateFiles = folderReader.getListFiles(file);
			
			
			for(String path : rateFiles){
				ratings = reader.read(path);
				
				String aux = ratings.get(0);
				aux = aux.replace(":", "");
				int Movie = Integer.parseInt(aux);
				ratings.remove(0);
				
				for(String rate : ratings){
					String[] auxVector = rate.split(",");
					int CustomerID  = Integer.parseInt(auxVector[0]);
					int MovieID  = Movie;
					int Rate  = Integer.parseInt(auxVector[1]);
					String Date = auxVector[2];
					
					System.out.println("MovieID:" + MovieID);
					
					dataInsert.insertRating(CustomerID, MovieID, Rate, Date);
				}
				
				System.out.println("Done");
			}
			
			con.close();
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		
		
		/**
		try{
			con = connectionFactory.getConnection("./data/netflix.db");
			dataInsert = new DataInsert(con);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		try {
			movies = reader.read("./NetflixFiles/movie_titles.txt");
		} catch (IOException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println("Inserting...");
		
		for(String movie : movies){
			String[] auxVector = movie.split(",");
			int MovieID  = Integer.parseInt(auxVector[0]);
			int YearOfRelease  = Integer.parseInt(auxVector[1]);
			String Title = auxVector[2];
			int Genre = randomNumber.nextInt(11);
			
			System.out.println("Movie ID:" + MovieID);
			
			dataInsert.insertMovie(MovieID, YearOfRelease, Title, Genre);
		}
		
		System.out.println("Done");
		con.close();
		
		**/
	}
}
