package com.ufabc.fuzzy.converter;

import java.io.File;
import java.util.ArrayList;

public class FolderReader {
	
	
	public ArrayList<String> getListFiles(File folder){
		
		ArrayList<String> fileList = new ArrayList<String>();
		
		File[] files = folder.listFiles();
		
		
		for(int i = 0;i < files.length;i++){
			
			String path = files[i].getPath();
			fileList.add(path);
			
		}
		
		return fileList;
	}
}
