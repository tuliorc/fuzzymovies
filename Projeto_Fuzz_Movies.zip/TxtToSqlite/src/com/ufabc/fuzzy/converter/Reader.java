package com.ufabc.fuzzy.converter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;


public class Reader {
	
	public ArrayList<String> read(String path) throws IOException{
		
		ArrayList<String> lines = new ArrayList<String>();
		BufferedReader bufferedReader = null;
		FileReader fileReader = null;
		
		try{
			fileReader = new FileReader(path);
			bufferedReader = new BufferedReader(fileReader);
			String auxString = null;
			
			while( (auxString = bufferedReader.readLine()) != null){
				lines.add(auxString);
			}
			
		}
		
		catch(Exception e){
			
			System.out.print(e.getMessage());
			
		}
		
		finally{
			bufferedReader.close();
			fileReader.close();
		}
		
		return lines;
	}
}
