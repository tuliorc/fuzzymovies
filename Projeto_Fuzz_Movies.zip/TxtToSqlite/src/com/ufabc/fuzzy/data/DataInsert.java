package com.ufabc.fuzzy.data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class DataInsert {
	 
	Connection c = null;
	
	public DataInsert(Connection c){
		this.c = c;
		
	}
	
	public void insertMovie(int MovieID, int YearOfRelease, String Title, int Genre){
		
		  
			try {
				
				 PreparedStatement insertMovies = null;  	
				 c.setAutoCommit(false); 
				
				 String sql = "INSERT INTO Movies (MovieID,YearOfRelease,Title, Genre) " +
		                      "VALUES (?, ?, ?, ?);";   
				
				 insertMovies = c.prepareStatement(sql);
			     insertMovies.setInt(1, MovieID);
			     insertMovies.setInt(2, YearOfRelease); 
			     insertMovies.setString(3,Title); 
			     insertMovies.setInt(4, Genre); 
			     
			     
			     insertMovies.executeUpdate();
			     insertMovies.close();
			      
			     c.commit();
		    } 
		    catch (Exception e ) {
		    	System.err.println( e.getClass().getName() + ": " + e.getMessage() );
		    }
	}
	
	public void insertRating(int CustomerID,int MovieID, int Rate, String Date){
		
		  
		try {
			
			 PreparedStatement insertRatings = null;  	
			 c.setAutoCommit(false); 
			
			 String sql = "INSERT INTO Ratings (CustomerID,MovieID,Rate, Date) " +
	                      "VALUES (?, ?, ?, ?);";   
			
			 insertRatings = c.prepareStatement(sql);
			 insertRatings.setInt(1, CustomerID);
			 insertRatings.setInt(2, MovieID); 
			 insertRatings.setInt(3,Rate); 
			 insertRatings.setString(4, Date); 
		     
		     
			 insertRatings.executeUpdate();
			 insertRatings.close();
		      
		     c.commit();
	    } 
	    catch (Exception e ) {
	    	System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	    }
}

}
